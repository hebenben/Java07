import javafx.geometry.Point2D;
public class PartImage {
    private boolean[][] pixels;
    private boolean[][] visited;
    private int rows;
    private int cols;

    public PartImage(int r, int c) {
        rows = r;
        cols = c;
        visited = new boolean[r][c];
        pixels = new boolean[r][c];
    }
    public PartImage(int rw, int cl, byte[][] data) {
        this(rw,cl);
        for (int r=0; r<10; r++) {
            for (int c=0; c<10; c++) {
                if (data[r][c] == 1)
                    pixels[r][c] = true;
                else
                    pixels[r][c]= false;
            }
        }
    }
    public int getRows() { return rows; }
    public int getCols() { return cols; }
    public boolean getPixel(int r, int c) { return pixels[r][c]; }
    // You will re-write the 5 methods below
    public void print() {
        String s = "";
        for (boolean[] col : pixels) {
            for (boolean row : col) {
                if (row) {
                    s += "*";
                }
                else {
                    s += "-";
                }
            }
            s += "\n";
        }
        System.out.printf(s);
    }
    public Point2D findStart() {
        for (int i = 0; i < cols; i++) {
            for (int j = 0; j < rows; j++) {
                if (pixels[i][j]) {
                    return new Point2D(j, i);
                }
            }
        }
        return null;
    }
    public int partSize() {
        int c = 0;
        for (boolean[] col : pixels) {
            for (boolean row : col) {
                if (row) {
                    c++;
                }
            }
        }
        return c;
    }
    private void expandFrom(int r, int c) {
        pixels[r][c] = false;
        if(r+1 < rows && pixels[r+1][c]) {
            expandFrom(r+1, c);
        }
        if(r-1 >= 0 && pixels[r-1][c]) {
            expandFrom(r-1, c);
        }
        if(c+1 < cols && pixels[r][c+1]) {
            expandFrom(r, c+1);
        }
        if(c-1 >= 0 && pixels[r][c-1]) {
            expandFrom(r, c-1);
        }
    }
    private int perimeterOf(int r, int c) {
        int flag = 0, perimeter = 0;
        visited[r][c] = true;
        if(r==0 || r==rows-1){
            flag += 1;
        }
        if(c==0 || c==cols-1){
            flag += 1;
        }
        if(r-1 >= 0 && !visited[r-1][c]){
            if(pixels[r-1][c]){
                perimeter += perimeterOf(r-1, c);
            }
            else{
                flag += 1;
            }
        }
        if(r+1 < rows && !visited[r+1][c]){
            if(pixels[r+1][c]){
                perimeter += perimeterOf(r+1, c);
            }
            else{
                flag += 1;
            }
        }
        if(c-1 >= 0 && !visited[r][c-1]){
            if(pixels[r][c-1]){
                perimeter += perimeterOf(r, c-1);
            }
            else{
                flag += 1;
            }
        }
        if(c+1 < cols && !visited[r][c+1]){
            if(pixels[r][c+1]){
                perimeter += perimeterOf(r, c+1);
            }
            else{
                flag += 1;
            }
        }
        return flag + perimeter;
    }
    public boolean isBroken() {
        Point2D p = findStart();
        expandFrom((int) p.getX(), (int) p.getY());
        return (partSize() != 0);
    }
    public int perimeter() {
        Point2D p = findStart();
        return perimeterOf((int)p.getX(), (int)p.getY());
    }
    public static PartImage exampleA() {
        byte[][] pix = {{0,0,0,0,0,0,0,0,0,0},
                {0,1,1,1,1,1,1,0,0,0},
                {0,1,1,1,1,1,1,0,0,0},
                {0,1,1,1,1,1,1,1,1,0},
                {0,0,0,1,1,1,1,1,1,0},
                {0,1,1,1,1,1,1,1,1,0},
                {0,1,1,1,1,1,1,1,1,0},
                {0,1,1,1,1,1,1,0,0,0},
                {0,0,0,0,1,1,1,0,0,0},
                {0,0,0,0,0,0,0,0,0,0}};
        return new PartImage(10,10, pix);
    }
    public static PartImage exampleB() {
        byte[][] pix = {{1,0,1,0,1,0,1,0,0,0},
                {1,0,1,0,1,0,1,1,1,1},
                {1,0,1,0,1,0,1,0,0,0},
                {1,0,1,0,1,0,1,1,1,1},
                {1,0,1,0,1,0,1,0,0,0},
                {1,0,1,0,1,0,1,1,1,1},
                {1,1,1,1,1,1,1,0,0,0},
                {0,1,0,1,0,0,1,1,1,1},
                {0,1,0,1,0,0,1,0,0,0},
                {0,1,0,1,0,0,1,0,0,0}};
        return new PartImage(10,10, pix);
    }
    public static PartImage exampleC() {
        byte[][] pix = {{1,1,1,0,0,0,1,0,0,0},
                {1,1,1,1,0,0,1,1,1,0},
                {1,1,1,1,1,1,1,1,1,1},
                {0,1,1,1,0,0,1,0,0,0},
                {0,0,1,0,0,0,0,0,0,0},
                {1,0,0,0,1,1,0,1,1,1},
                {1,1,0,1,1,1,1,1,1,1},
                {1,1,1,1,1,1,1,1,1,1},
                {0,0,1,1,0,1,1,1,1,1},
                {0,0,1,0,0,0,1,1,0,0}};
        return new PartImage(10,10, pix);
    }
    public static PartImage exampleD() {
        byte[][] pix = {{1,0,1,0,1,0,1,1,0,0},
                {1,0,1,0,0,0,1,0,0,0},
                {0,0,0,0,0,0,0,0,1,1},
                {1,0,1,1,1,1,1,1,1,0},
                {1,0,0,1,0,0,1,0,0,0},
                {1,1,0,0,0,1,1,0,0,1},
                {0,1,0,0,0,0,0,0,1,1},
                {0,1,0,1,0,0,0,0,0,0},
                {0,0,0,1,1,1,0,0,0,0},
                {0,0,0,0,0,1,1,0,0,0}};
        return new PartImage(10,10, pix);
    }
}